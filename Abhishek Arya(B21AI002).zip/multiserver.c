#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include<unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 8080

void *handle_client(void *arg)
{
    int socket = *(int*) arg;
    char p[]="Client conection removed";
    

    char buffer[1024] = {0};

    // Managing the request 
    
    while(1)
    {
    int val_1, val_2, ans;
        char command,result[1024];
        ;
        int valread = read(socket , buffer, 1024);
        //solving the expression
        
        if(valread <= 0)
            break;
        else
        {
        printf("Received expression: %s\n", buffer);
        }

        // Evaluate the expression
      
        sscanf(buffer, "%d %c %d", &val_1, &command, &val_2);
        if(command=='*')
        {
        ans=val_1*val_2;
        }else if(command=='+')
        {
        ans=val_1+val_2;
        }
        else if(command=='/')
        {ans=val_1/val_2;
        }
        else
        {ans=val_1-val_2;
        }
       

        //Printing the result
        sprintf(result, "%d", ans);
        send(socket, result, strlen(result), 0);

       //Now clear value in buffer
        memset(buffer, 0, sizeof(buffer));
    }
    
    printf("x\n");

    close(socket);

    
}

void main()
{
struct sockaddr_in address;
    int addrlen = sizeof(address);
    int server_fd, new_socket, valread;
    

    //Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("Socket connection failed");
        exit(EXIT_FAILURE);
    }
    //else{

    //Setting server AS TCP
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons( PORT );
//Binding of port type
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address))<0)
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    // Incomeing connection
    //cilent hearing
    if (listen(server_fd, 3) < 0)
    {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d\n", PORT);

    while(1)
    {
    char h[]="New client connected";
        // Accept incoming connection
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen))<0)
        {
            perror("accept");
            exit(EXIT_FAILURE);
        }

        printf("h\n");

        //handle multiple client
        pthread_t thread_id;
        //chacking for valid 
        if(pthread_create(&thread_id, NULL, handle_client, (void*) &new_socket) < 0)
        {
            perror("could not create thread");
            return;
        }

        pthread_detach(thread_id);
    }
    

   
}



